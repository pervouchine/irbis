irbis
=====

A package for ultrafast detection of conserved complementary n-mers in a set of orthologous sequences