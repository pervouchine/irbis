//	Copyright 2011,2012 Dmitri Pervouchine (dp@crg.eu)
//	This file is a part of the IRBIS package.
//	IRBIS package is free software: you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or
//	(at your option) any later version.
//	
//	IRBIS package is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//	
//	You should have received a copy of the GNU General Public License
//	along with IRBIS package.  If not, see <http://www.gnu.org/licenses/>.

#include "dictionary.h"
#include "orderedset.h"
#include "relation.h"

extern int lowercase_allowed;
extern int SAMEWINDOW;


int main(int argc, char** argv) {
    char buff[MAXBUFFLENGTH];
    char aux[MAXBUFFLENGTH];

    dictionary<ATOMIC>* dict_f[MAXSPECIES];
    dictionary<ATOMIC>* dict_r[MAXSPECIES];
    dictionary<PAIR<ATOMIC> >* dict_bp[MAXSPECIES];
    dictionary<ATOMIC>* filter;

    conservation_table* cons_f[MAXSPECIES];
    conservation_table* cons_r[MAXSPECIES];

    char right_file_name[MAXBUFFLENGTH]="";
    char left_file_name[MAXBUFFLENGTH]="";
    char right_cons_file_name[MAXBUFFLENGTH]="";
    char left_cons_file_name[MAXBUFFLENGTH]="";
    char right_sbs_file_name[MAXBUFFLENGTH]="";
    char left_sbs_file_name[MAXBUFFLENGTH]="";

    char rel_binary_file_name[MAXBUFFLENGTH]="";
    char rel_tabdel_file_name[MAXBUFFLENGTH]="";

    relation* rel=NULL;

    FILE *right_file, *left_file, *rel_file, *outfile;
    FILE *right_cons_file, *left_cons_file; 

    char* specie_name[MAXSPECIES];
    double weight[MAXSPECIES];

    char filename[MAXBUFFLENGTH];
    char outfilename[MAXBUFFLENGTH];

    double threshold, threshold1, threshold2;
    int halfsize,gap,n_species;
    int halfsize1,gap1,n_species1;
    double tot_weight=0;
    int right_end=0;

    int redundant_pairs = 2;
    const char RED_P[3][24]={"strictly not allowed", "not allowed", "allowed"};

    double min_cons = 0;
    int min_length   = 0;
    int joint_fold = 1;
    int number_of_gt_basepairs=0;

    index_t p,q,r,s;
    word_t a,b;
    int i,j;
    int repeat_length=1;
    int min_gc=0;
    char *pc;
    word_t aux_array[GT_ARRAY_CAPACITY];
    int aux_array_length;
    int n,m;

    int the_id=-1;

    subset *left_restriction=NULL;
    subset *right_restriction=NULL;

    if(argc==1) {
	exit(0);
    }

    timestamp_set();
    for(i=1;i<argc;i++) {
        pc = argv[i];
        if(*pc == '-') {
	    if(strcmp(pc+1,"i") == 0)  sscanf(argv[++i], "%s",  &left_file_name[0]);
	    if(strcmp(pc+1,"n") == 0)  sscanf(argv[++i], "%i",  &the_id);
        }
    }


    if(redundant_pairs>2) redundant_pairs=2;
    if(verbose) fprintf(logfile,"[Params: max_gt=%i, threshold=%2.1lf%%, min_length=%i, min_cons_score=%2.1lf, redundant_pairs=%s, joint_fold=%s]\n",
            number_of_gt_basepairs, threshold*100, min_length, min_cons, RED_P[redundant_pairs], yesno(joint_fold));

    if(verbose) fprintf(logfile,"Reading left %s", left_file_name);
    left_file = fopen(left_file_name,"r");
    if(left_file==NULL) {
	fprintf(stderr,"cannot be found, exiting\n");
	exit(1);
    }

    fgets(buff, MAXBUFFLENGTH, left_file);
    sscanf(buff,"%i %i %i %lf",&halfsize, &gap, &n_species, &threshold1);
    if(verbose) fprintf(logfile,"\n");
    for(i=0;i<n_species;i++) {
        dict_f[i] = new dictionary<ATOMIC>(halfsize,gap);
	fgets(buff, MAXBUFFLENGTH, left_file);
	specie_name[i] = (char*)malloc(sizeof(char)*MAXBUFFLENGTH);
	sscanf(buff,"%s %lf",&specie_name[i][0],&weight[i]);
 	tot_weight+=weight[i];
        if(verbose) fprintf(logfile,"[Loading %s ",specie_name[i]);
        dict_f[i]->load(left_file);
        dict_f[i]->info();
        dict_f[i]->check();
        if(verbose) fprintf(logfile,"]\n");
    }

    for(a=0; a<dict_f[0]->last_word;a++) {
	for(j=dict_f[0]->index[a];j<dict_f[0]->index[a+1];j++) {
	    if(dict_f[0]->table[j].getid()==the_id) {
		dict_f[0]->print_word(a);
		printf("\t%i\t%i\t%i\n", dict_f[0]->table[j].getid(), dict_f[0]->table[j].getpos(), dict_f[0]->table[j].getgap());
	    }
	}
    }

    timestamp_report();
    return(0);
}
