irbis-r2.1
==========

A package for ultrafast detection of conserved complementary n-mers in a set of orthologous sequences. Release 2.1